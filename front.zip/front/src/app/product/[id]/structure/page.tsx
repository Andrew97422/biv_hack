"use client";

import React, { useEffect, useState } from "react";
import {
	ReactFlow,
	Background,
	Controls,
	MiniMap,
	Node,
	Edge,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import NodeElement, { NodeElementProps } from "@/components/NodeElement";
import axios from "axios";

export type StructurePageProps = {
	params: Promise<{
		id: string;
	}>;
};

type CustomNode = Node<NodeElementProps["data"]>;

const nodeTypes = { nodeElement: NodeElement };

export default function Structure(props: StructurePageProps) {
	const params = React.use(props.params);
	const { id } = params;

	const [nodes, setNodes] = useState<CustomNode[]>([]);
	const [edges, setEdges] = useState<Edge[]>([]);

	useEffect(() => {
		async function fetchTree() {
			try {
				// Получаем данные о корне и дереве
				const { data: rootData } = await axios.get(
					`/api/products/${id}`
				);
				const { data: treeData } = await axios.get(`/api/nodes/${id}`);

				// Функция для вычисления позиций и обработки дерева
				const generateTree = (
					tree: any[],
					parentNodeId: string | null = null,
					depth = 1,
					xOffset = 0
				) => {
					const levelSpacing = 300; // Расстояние между уровнями
					const nodeSpacing = 400; // Расстояние между узлами в одном уровне
					let currentXOffset = xOffset;

					const nodes: CustomNode[] = [];
					const edges: Edge[] = [];

					tree.forEach((node, index) => {
						const nodeId = node.id;
						const position = {
							x: currentXOffset,
							y: depth * levelSpacing,
						};

						// Добавляем узел
						nodes.push({
							id: nodeId,
							position,
							type: "nodeElement",
							draggable: true,
							data: {
								path: node.path,
								entity:
									node.path.split(".").length === 2
										? "Объект страхования"
										: node.path.split(".").length === 3
										? "Вид страхования"
										: "Риски страхования",
								name: node.name,
								description: node.description,
							},
						});

						// Добавляем ребро, если есть родитель
						if (parentNodeId) {
							edges.push({
								id: `edge-${parentNodeId}-${nodeId}`,
								source: parentNodeId,
								target: nodeId,
								animated: true,
								style: { stroke: "#555" },
							});
						}

						// Рекурсивно добавляем дочерние элементы
						if (node.children) {
							const childResults = generateTree(
								node.children,
								nodeId,
								depth + 1,
								currentXOffset
							);

							// Сдвигаем X для следующего узла на этом уровне
							currentXOffset +=
								nodeSpacing * (childResults.totalNodes || 1);

							// Добавляем дочерние узлы и рёбра
							nodes.push(...childResults.nodes);
							edges.push(...childResults.edges);
						} else {
							// Сдвигаем X для следующего узла
							currentXOffset += nodeSpacing;
						}
					});

					console.log(edges);

					return { nodes, edges, totalNodes: tree.length };
				};

				// Генерируем дерево
				const { nodes: treeNodes, edges: treeEdges } = generateTree(
					treeData,
					id
				);

				// Добавляем корневой узел
				const rootNode: CustomNode = {
					id: rootData.id,
					position: { x: 0, y: 0 },
					type: "nodeElement",
					data: {
						path: rootData.id,
						entity: "Страховой продукт",
						name: rootData.name,
						description: rootData.description,
					},
				};

				//console.log(JSON.stringify([rootNode, ...treeNodes], null, 4))

				// Обновляем состояние
				setNodes([rootNode, ...treeNodes]);
				setEdges(treeEdges);
			} catch (error) {
				console.error("Error fetching tree data:", error);
			}
		}

		fetchTree();
	}, [id]);

	return (
		<div style={{ width: "100%", height: "100vh" }}>
			<ReactFlow
				nodes={nodes}
				edges={edges}
				nodeTypes={nodeTypes}
				fitView
			>
				<Background />
				<Controls />
				<MiniMap />
			</ReactFlow>
		</div>
	);
}
