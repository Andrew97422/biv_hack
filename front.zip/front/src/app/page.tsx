"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
	Dialog,
	DialogContent,
	DialogHeader,
	DialogTitle,
	DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Folder, Edit, Trash2, ExternalLink, PlusCircle } from "lucide-react";
import axios from "axios";

interface Product {
	id: string;
	name: string;
	description: string;
}

export default function Home() {
	const [products, setProducts] = useState<Product[]>([]);
	const [loading, setLoading] = useState<boolean>(false);
	const [error, setError] = useState<string | null>(null);
	const [selectedId, setSelectedId] = useState<string | null>(null);
	const [modalIsOpen, setModalIsOpen] = useState(false);
	const [modalType, setModalType] = useState<
		"edit" | "delete" | "add" | null
	>(null);
	const [selectedProduct, setSelectedProduct] = useState<Product | null>(
		null
	);
	const [confirmAction, setConfirmAction] = useState(false); // Для подтверждения действий

	const [formData, setFormData] = useState({
		name: "",
		description: "",
	});

	useEffect(() => {
		async function fetchProducts() {
			setLoading(true);
			setError(null);
			try {
				const { data } = await axios.get("/api/products");
				setProducts(data);
			} catch (err) {
				setError("Ошибка при загрузке продуктов");
			} finally {
				setLoading(false);
			}
		}

		fetchProducts();
	}, []);

	const handleOpenModal = (
		type: "edit" | "delete" | "add",
		product?: Product,
		e?: React.MouseEvent
	) => {
		if (e) e.stopPropagation();
		setModalType(type);
		setSelectedProduct(product || null);
		setFormData({
			name: product?.name || "",
			description: product?.description || "",
		});
		setModalIsOpen(true);
		setConfirmAction(false); // Сбрасываем подтверждение при открытии модалки
	};

	const handleCloseModal = () => {
		setModalIsOpen(false);
		setModalType(null);
		setSelectedProduct(null);
		setConfirmAction(false); // Сбрасываем подтверждение
		setFormData({ name: "", description: "" }); // Сбрасываем форму
	};

	const handleAddProduct = async () => {
		const { name, description } = formData;
		setLoading(true);
		try {
			const { data: newProductId } = await axios.post("/api/products", {
				name,
				description,
			});
			const { data: newProduct } = await axios.get(
				`/api/products/${newProductId}`
			);
			setProducts((prev) => [...prev, newProduct]);
			handleCloseModal();
		} catch (err) {
			setError("Ошибка при добавлении продукта");
		} finally {
			setLoading(false);
		}
	};

	const handleEditProduct = async () => {
		if (selectedProduct) {
			const { name, description } = formData;
			setLoading(true);
			try {
				await axios.put(`/api/products/${selectedProduct.id}`, {
					name,
					description,
				});

				try {
					const { data } = await axios.get("/api/products");
					setProducts(data);
				} catch (err) {
					setError("Ошибка при загрузке продуктов");
				} finally {
					setLoading(false);
				}
				handleCloseModal();
			} catch (err) {
				setError("Ошибка при редактировании продукта");
			} finally {
				setLoading(false);
			}
		}
	};

	const handleDeleteProduct = async () => {
		if (selectedProduct) {
			setLoading(true);
			try {
				await axios.delete(`/api/products/${selectedProduct.id}`);
				setProducts(
					products.filter(
						(product) => product.id !== selectedProduct.id
					)
				);
				handleCloseModal();
			} catch (err) {
				setError("Ошибка при удалении продукта");
			} finally {
				setLoading(false);
			}
		}
	};

	return (
		<div className="min-h-screen bg-gray-200 p-8 flex justify-center items-center">
			<div className="grow relative max-w-6xl h-[500px] mx-auto overflow-y-auto px-8 bg-gradient-to-b from-gray-400 to-gray-300 py-10 border-solid border-gray-600 border-[6px]">
				{loading && (
					<div className="text-center text-yellow-600">
						Загрузка...
					</div>
				)}
				{error && (
					<div className="text-center text-red-600">{error}</div>
				)}
				{products.map((product, index) => (
					<motion.div
						key={product.id}
						layoutId={product.id}
						className="relative"
						initial={{ y: index * 10 }}
						animate={{
							y: selectedId === product.id ? -20 : index * 10,
							scale: selectedId === product.id ? 1.02 : 1,
						}}
						transition={{
							type: "spring",
							stiffness: 300,
							damping: 30,
						}}
						style={{
							zIndex: product.id === selectedId ? 10 : index,
						}}
						onClick={() =>
							setSelectedId(
								selectedId === product.id ? null : product.id
							)
						}
					>
						{/* Продукт */}
						<div
							className={`w-full ${
								selectedId === product.id ? "h-64" : "h-24"
							} bg-yellow-200 rounded-lg shadow-lg transition-all duration-300 hover:bg-yellow-300 cursor-pointer relative overflow-hidden`}
						>
							<div className="absolute top-5 right-0 text-yellow-300 bg-yellow-300 text-sm py-1 px-2 rounded-bl-xl">
								use client
							</div>

							<div className="absolute top-0 left-0 right-0 h-8 bg-yellow-300 rounded-t-lg" />

							<div className="relative p-4 pt-10">
								<div className="flex items-center gap-2">
									<Folder className="w-6 h-6 text-yellow-600" />
									<h2 className="text-xl font-bold text-yellow-800">
										{product.name}
									</h2>
								</div>

								<AnimatePresence>
									{selectedId === product.id && (
										<motion.div
											initial={{ opacity: 0, height: 0 }}
											animate={{
												opacity: 1,
												height: "auto",
											}}
											exit={{ opacity: 0, height: 0 }}
											className="mt-4 space-y-4"
										>
											<p className="text-yellow-900">
												{product.description}
											</p>

											<div className="flex gap-2">
												<Button
													variant="outline"
													className="bg-white hover:bg-yellow-50"
													onClick={(e) => {
														e.stopPropagation();
														window.location.href = `/product/${product.id}/structure`;
													}}
												>
													<ExternalLink className="w-4 h-4 mr-2" />
													Изучить
												</Button>
												<Button
													variant="outline"
													className="bg-white hover:bg-green-50"
													onClick={(e) =>
														handleOpenModal(
															"edit",
															product,
															e
														)
													}
												>
													<Edit className="w-4 h-4 mr-2" />
													Редактировать
												</Button>
												<Button
													variant="outline"
													className="bg-white hover:bg-red-50"
													onClick={(e) =>
														handleOpenModal(
															"delete",
															product,
															e
														)
													}
												>
													<Trash2 className="w-4 h-4 mr-2" />
													Удалить
												</Button>
											</div>
										</motion.div>
									)}
								</AnimatePresence>
							</div>
						</div>
					</motion.div>
				))}

				{/* Кнопка добавления продукта */}
				<Button
					className="sticky bottom-1 left-full bg-green-500 hover:bg-green-600 text-white z-50"
					onClick={() => handleOpenModal("add")}
				>
					<PlusCircle className="w-6 h-6 mr-2" />
					Добавить новый продукт
				</Button>
			</div>

			{/* Модалки */}
			<Dialog
				open={modalIsOpen}
				onOpenChange={(open) => !open && handleCloseModal()}
			>
				<DialogContent className="sm:max-w-md">
					{modalType === "edit" && selectedProduct && (
						<div className="space-y-4">
							<DialogHeader>
								<DialogTitle>Редактировать продукт</DialogTitle>
							</DialogHeader>
							<div className="space-y-4">
								<div>
									<label className="text-sm font-medium">
										Название
									</label>
									<Input
										value={formData.name}
										className="mt-1"
										onChange={(e) =>
											setFormData({
												...formData,
												name: e.target.value,
											})
										}
									/>
								</div>
								<div>
									<label className="text-sm font-medium">
										Описание
									</label>
									<Textarea
										value={formData.description}
										className="mt-1"
										onChange={(e) =>
											setFormData({
												...formData,
												description: e.target.value,
											})
										}
									/>
								</div>
							</div>
							<div className="flex justify-end gap-2">
								<Button
									variant="outline"
									onClick={handleCloseModal}
								>
									Отмена
								</Button>
								<Button
									onClick={() => {
										if (confirmAction && selectedProduct) {
											handleEditProduct();
										} else {
											setConfirmAction(true);
										}
									}}
								>
									{confirmAction
										? "Подтвердить"
										: "Редактировать"}
								</Button>
							</div>
						</div>
					)}
					{modalType === "add" && (
						<div className="space-y-4">
							<DialogHeader>
								<DialogTitle>
									Добавить новый продукт
								</DialogTitle>
							</DialogHeader>
							<div className="space-y-4">
								<div>
									<label className="text-sm font-medium">
										Название
									</label>
									<Input
										value={formData.name}
										className="mt-1"
										onChange={(e) =>
											setFormData({
												...formData,
												name: e.target.value,
											})
										}
									/>
								</div>
								<div>
									<label className="text-sm font-medium">
										Описание
									</label>
									<Textarea
										value={formData.description}
										className="mt-1"
										onChange={(e) =>
											setFormData({
												...formData,
												description: e.target.value,
											})
										}
									/>
								</div>
							</div>
							<div className="flex justify-end gap-2">
								<Button
									variant="outline"
									onClick={handleCloseModal}
								>
									Отмена
								</Button>
								<Button
									onClick={() => {
										if (confirmAction) {
											handleAddProduct();
										} else {
											setConfirmAction(true);
										}
									}}
								>
									{confirmAction ? "Подтвердить" : "Добавить"}
								</Button>
							</div>
						</div>
					)}
					{modalType === "delete" && selectedProduct && (
						<div className="space-y-4">
							<DialogHeader>
								<DialogTitle>Удалить продукт?</DialogTitle>
								<DialogDescription>
									Вы действительно хотите удалить продукт "
									{selectedProduct.name}"?
								</DialogDescription>
							</DialogHeader>
							<div className="flex justify-end gap-2">
								<Button
									variant="outline"
									onClick={handleCloseModal}
								>
									Отмена
								</Button>
								<Button
									variant="destructive"
									onClick={() => {
										if (confirmAction && selectedProduct) {
											handleDeleteProduct();
										} else {
											setConfirmAction(true);
										}
									}}
								>
									{confirmAction ? "Подтвердить" : "Удалить"}
								</Button>
							</div>
						</div>
					)}
				</DialogContent>
			</Dialog>
		</div>
	);
}
