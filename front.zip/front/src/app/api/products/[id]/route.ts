import axios from "axios";
import { NextRequest, NextResponse } from "next/server";

interface GetProductResponse {
	id: string;
	name: string;
	description: string;
}

export async function GET(
	request: Request,
	{ params }: { params: { id: string } }
) {
	const { id } = params;

	try {
		const response = await axios.get<GetProductResponse>(
			`${process.env.API_BASE_URL}/products/${id}`
		);

		return NextResponse.json(response.data);
	} catch (error) {
		return NextResponse.error();
	}
}

export async function DELETE(
	request: Request,
	{ params }: { params: { id: string } }
) {
	const { id } = params;

	try {
		const response = await axios.delete(
			`${process.env.API_BASE_URL}/products/${id}`
		);

		return NextResponse.json(response.data);
	} catch (error) {
		return NextResponse.error();
	}
}

export async function PUT(
	request: NextRequest,
	{ params }: { params: { id: string } }
) {
	const { id } = params;

	const body = await request.json();

	try {
		const response = await axios.put(
			`${process.env.API_BASE_URL}/products/${id}`,
			body
		);

		return NextResponse.json(response.data);
	} catch (error) {
		return NextResponse.error();
	}
}
