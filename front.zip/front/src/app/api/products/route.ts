import { NextRequest, NextResponse } from "next/server";
import axios from "axios";

export async function GET() {
	try {
		const response = await axios.get(
			`${process.env.API_BASE_URL}/products`
		);

		return NextResponse.json(response.data);
	} catch (error) {
		return NextResponse.error();
	}
}

export async function POST(request: NextRequest) {
	const body = await request.json();

	try {
		const response = await axios.post(
			`${process.env.API_BASE_URL}/products`,
			body
		);

		return NextResponse.json(response.data);
	} catch (error) {
		return NextResponse.error();
	}
}
