import { Description } from "@radix-ui/react-dialog";
import axios from "axios";
import { NextRequest, NextResponse } from "next/server";

export type NodeData = {
	id: string;
	name: string;
	description: string;
	parameters: null;
	path: string;
};

// Рекурсивная функция для построения дерева
const buildTree = (nodes: NodeData[], parentPath: string): NodeData[] => {
	return nodes
		.filter(
			(node) =>
				node.path.startsWith(parentPath) &&
				node.path.split(".").length === parentPath.split(".").length + 1
		)
		.map((node) => ({
			...node,
			children: buildTree(nodes, `${parentPath}.${node.id}`),
		}));
};

export async function GET(
	request: Request,
	{ params }: { params: { id: string } }
) {
	const { id: productId } = params;

	try {
		const { data: allPathData } = await axios.get(
			`${process.env.API_BASE_URL}/path/all`
		);

		const tree = buildTree(allPathData, productId);

		return NextResponse.json(tree);
	} catch (error) {
		console.error("Error while building the tree:", error);
		return NextResponse.error();
	}
}

export async function DELETE(
	request: Request,
	{ params }: { params: { id: string } }
) {
	const deletePath = params?.id;

	if (!deletePath) {
		return NextResponse.json(
			{ error: "ID parameter is required" },
			{ status: 400 }
		);
	}

	try {
		const apiResponse = await axios.delete(
			`${process.env.API_BASE_URL}/path`,
			{ params: { path: deletePath } }
		);

		return NextResponse.json(apiResponse.data, {
			status: apiResponse.status,
		});
	} catch (error: any) {
		console.error("API error:", error);

		const status = error.response?.status || 500;
		const message =
			error.response?.data?.message || "Internal server error";

		return NextResponse.json({ error: message }, { status });
	}
}

export async function POST(
	request: NextRequest,
	{ params }: { params: { id: string } }
) {
	const postPath = params?.id;

	const body = await request.json();

	if (!postPath) {
		return NextResponse.json(
			{ error: "ID parameter is required" },
			{ status: 400 }
		);
	}

	try {
		const apiResponse = await axios.post(
			`${process.env.API_BASE_URL}/path?path=${postPath}`,
			{ ...body, parameters: null }
		);

		return NextResponse.json(apiResponse.data, {
			status: apiResponse.status,
		});
	} catch (error: any) {
		console.error("API error:", error);

		const status = error.response?.status || 500;
		const message =
			error.response?.data?.message || "Internal server error";

		return NextResponse.json({ error: message }, { status });
	}
}

export async function PUT(
	request: NextRequest,

	{ params }: { params: { id: string } }
) {
	const postPath = params?.id;

	const body = await request.json();

	if (!postPath) {
		return NextResponse.json(
			{ error: "ID parameter is required" },
			{ status: 400 }
		);
	}

	try {
		const apiResponse = await axios.put(
			`${process.env.API_BASE_URL}/path?path=${postPath}`,
			{ ...body, parameters: null }
		);

		return NextResponse.json(apiResponse.data, {
			status: apiResponse.status,
		});
	} catch (error: any) {
		console.error("API error:", error);

		const status = error.response?.status || 500;
		const message =
			error.response?.data?.message || "Internal server error";

		return NextResponse.json({ error: message }, { status });
	}
}
