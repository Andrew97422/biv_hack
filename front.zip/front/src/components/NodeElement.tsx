"use client";

import { Handle, Position } from "@xyflow/react";
import { useState } from "react";
import axios from "axios";
import { Edit, Trash2, PlusCircle } from "lucide-react";
import {
	Dialog,
	DialogContent,
	DialogHeader,
	DialogTitle,
	DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useRouter } from "next/navigation";

export type NodeElementProps = {
	data: {
		entity:
			| "Вид страхования"
			| "Объект страхования"
			| "Риски страхования"
			| "Страховой продукт";
		name: string;
		description: string;
		path: string;
	};
};

export default function NodeElement({
	data: { path, entity, name, description },
}: NodeElementProps) {
	const level = path.split(".").length;
	const router = useRouter();

	const [modalIsOpen, setModalIsOpen] = useState(false);
	const [modalType, setModalType] = useState<
		"edit" | "delete" | "add" | null
	>(null);
	const [confirmAction, setConfirmAction] = useState(false);
	const [formData, setFormData] = useState({
		name: "",
		description: "",
	});
	const [error, setError] = useState<string | null>(null);
	const [loading, setLoading] = useState(false);

	const handleOpenModal = (type: "edit" | "delete" | "add") => {
		setModalType(type);
		if (type === "edit") {
			setFormData({
				name: name,
				description: description,
			});
		} else {
			setFormData({
				name: "",
				description: "",
			});
		}
		setModalIsOpen(true);
		setConfirmAction(false);
	};

	const handleCloseModal = () => {
		setModalIsOpen(false);
		setModalType(null);
		setConfirmAction(false);
		setFormData({ name: "", description: "" });
		setError(null);
	};

	const handleEdit = async () => {
		setLoading(true);
		try {
			await axios.put(`/api/nodes/${path}`, {
				name: formData.name,
				description: formData.description,
			});
			handleCloseModal();
		} catch (err) {
			setError("Ошибка при редактировании элемента");
		} finally {
			setLoading(false);
		}
	};

	const handleDelete = async () => {
		setLoading(true);
		try {
			await axios.delete(`/api/nodes/${path}`);
			handleCloseModal();
		} catch (err) {
			setError("Ошибка при удалении элемента");
		} finally {
			setLoading(false);
		}
	};

	const handleAdd = async () => {
		setLoading(true);
		try {
			await axios.post(`/api/nodes/${path}`, {
				name: formData.name,
				description: formData.description,
			});
			handleCloseModal();
		} catch (err) {
			setError("Ошибка при добавлении элемента");
		} finally {
			setLoading(false);
		}
	};

	const getNextEntityName = () => {
		if (level === 1) return "страховой объект";
		if (level === 2) return "страховой вид";
		return "страховой риск";
	};

	return (
		<>
			<div className="rounded-lg border bg-white shadow-lg overflow-hidden">
				{/* Верхняя полоска с сущностью */}
				<div className="bg-blue-500 text-white p-2 text-center text-sm font-semibold">
					{entity}
				</div>

				{/* Основное содержимое карточки */}
				<div className="p-4">
					<h1 className="text-xl font-bold mb-2">{name}</h1>
					<p className="text-gray-500 text-sm">{description}</p>
				</div>

				{/* Кнопки редактировать и удалить */}
				{entity !== "Страховой продукт" && (
					<div className="flex space-x-2 p-4 border-t bg-gray-100">
						<button
							className="flex-1 flex justify-center items-center py-2 px-4 text-white bg-blue-500 rounded hover:bg-blue-600"
							onClick={() => handleOpenModal("edit")}
						>
							<Edit className="mr-2" /> Редактировать
						</button>
						<button
							className="flex-1 flex justify-center items-center py-2 px-4 text-white bg-red-500 rounded hover:bg-red-600"
							onClick={() => handleOpenModal("delete")}
						>
							<Trash2 className="mr-2" /> Удалить
						</button>
					</div>
				)}

				{level !== 4 && (
					<button
						className="flex justify-center items-center w-full py-2 px-4 text-white bg-blue-500 rounded hover:bg-blue-600"
						onClick={() => handleOpenModal("add")}
					>
						<PlusCircle className="mr-2" /> Добавить{" "}
						{getNextEntityName()}
					</button>
				)}

				{/* Handles для связи */}
				<Handle type="target" position={Position.Top} id="top" />
				<Handle type="source" position={Position.Bottom} id="bottom" />
			</div>

			{/* Модальные окна */}
			<Dialog
				open={modalIsOpen}
				onOpenChange={(open) => !open && handleCloseModal()}
			>
				<DialogContent className="sm:max-w-md">
					{modalType === "edit" && (
						<div className="space-y-4">
							<DialogHeader>
								<DialogTitle>Редактировать элемент</DialogTitle>
							</DialogHeader>
							<div className="space-y-4">
								<div>
									<label className="text-sm font-medium">
										Название
									</label>
									<Input
										value={formData.name}
										className="mt-1"
										onChange={(e) =>
											setFormData({
												...formData,
												name: e.target.value,
											})
										}
									/>
								</div>
								<div>
									<label className="text-sm font-medium">
										Описание
									</label>
									<Textarea
										value={formData.description}
										className="mt-1"
										onChange={(e) =>
											setFormData({
												...formData,
												description: e.target.value,
											})
										}
									/>
								</div>
							</div>
							<div className="flex justify-end gap-2">
								<Button
									variant="outline"
									onClick={handleCloseModal}
								>
									Отмена
								</Button>
								<Button
									onClick={() => {
										if (confirmAction) {
											handleEdit();
										} else {
											setConfirmAction(true);
										}
									}}
									disabled={loading}
								>
									{loading
										? "Загрузка..."
										: confirmAction
										? "Подтвердить"
										: "Редактировать"}
								</Button>
							</div>
						</div>
					)}

					{modalType === "add" && (
						<div className="space-y-4">
							<DialogHeader>
								<DialogTitle>
									Добавить {getNextEntityName()}
								</DialogTitle>
							</DialogHeader>
							<div className="space-y-4">
								<div>
									<label className="text-sm font-medium">
										Название
									</label>
									<Input
										value={formData.name}
										className="mt-1"
										onChange={(e) =>
											setFormData({
												...formData,
												name: e.target.value,
											})
										}
									/>
								</div>
								<div>
									<label className="text-sm font-medium">
										Описание
									</label>
									<Textarea
										value={formData.description}
										className="mt-1"
										onChange={(e) =>
											setFormData({
												...formData,
												description: e.target.value,
											})
										}
									/>
								</div>
							</div>
							<div className="flex justify-end gap-2">
								<Button
									variant="outline"
									onClick={handleCloseModal}
								>
									Отмена
								</Button>
								<Button
									onClick={() => {
										if (confirmAction) {
											handleAdd();
										} else {
											setConfirmAction(true);
										}
									}}
									disabled={loading}
								>
									{loading
										? "Загрузка..."
										: confirmAction
										? "Подтвердить"
										: "Добавить"}
								</Button>
							</div>
						</div>
					)}

					{modalType === "delete" && (
						<div className="space-y-4">
							<DialogHeader>
								<DialogTitle>Удалить элемент?</DialogTitle>
								<DialogDescription>
									Вы действительно хотите удалить элемент "
									{name}"?
								</DialogDescription>
							</DialogHeader>
							<div className="flex justify-end gap-2">
								<Button
									variant="outline"
									onClick={handleCloseModal}
								>
									Отмена
								</Button>
								<Button
									variant="destructive"
									onClick={() => {
										if (confirmAction) {
											handleDelete();
										} else {
											setConfirmAction(true);
										}
									}}
									disabled={loading}
								>
									{loading
										? "Загрузка..."
										: confirmAction
										? "Подтвердить"
										: "Удалить"}
								</Button>
							</div>
						</div>
					)}

					{error && (
						<div className="text-red-500 text-sm mt-2">{error}</div>
					)}
				</DialogContent>
			</Dialog>
		</>
	);
}
